<template>
  <div class="loding">
      
  </div>
</template>
<script>
export default {
  props: ["content"],
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>
<style lang='scss' scoped>
.loding {
  width: 500px;
  height: 20px;
  background-color: bisque;
}
</style>