<template>
     <div>首页</div>
</template>


<script>


import  {login}  from "@/api/api.js"

export default {
  data() {
    return {
      
    }
  },
  created(){
        
  },
  
  methods: {
     
  },
  
}
</script>
<style lang="scss" scoped>

</style>